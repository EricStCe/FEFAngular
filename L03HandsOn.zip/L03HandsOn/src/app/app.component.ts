import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Mr. Bigglesworth';
  city = 'Fresno';
  tag_line = 'The place where you thought you wanted to live.';
  about_me = 'I live here wondering if this is the place where my kids will grow. So each day I work to further the lives and education of my children so that they know that they can do anything they have set their minds too doing. My wife is an inportant part of the process of raising these children as she is the one who home schools them each and every day.'
}
