export class Contact {
  firstName: string;
  lastName: string;
  phoneNumber: number;
  email: string;
}
